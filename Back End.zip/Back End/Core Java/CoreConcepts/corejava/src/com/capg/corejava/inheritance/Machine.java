package com.capg.corejava.inheritance;

public class Machine {
	void slot(Atm1 a)
	{
		a.validatecard();
		a.getinfo();
		
	}

}
