package com.capgemini.corejava.Arraytype;

public class BMS {

	public static void main(String[] args) {
		System.out.println("Main Started");
		PVR p = new PVR();
		try
		{
		p.confirm();
		}
		catch(ArithmeticException w)
		{
			System.out.println("exception caught at main");
		}
		System.out.println("Main Ended");

	}

}
