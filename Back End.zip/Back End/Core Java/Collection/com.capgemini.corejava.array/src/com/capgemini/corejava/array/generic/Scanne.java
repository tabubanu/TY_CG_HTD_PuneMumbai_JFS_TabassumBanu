package com.capgemini.corejava.array.generic;
import java.util.Scanner;
public class Scanne {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the name");
		String name = sc.nextLine();
		System.out.println("Enter the age");
		int age = sc.nextInt();
		System.out.println("enter the height");
		double height = sc.nextDouble();
		
		System.out.println("Name is "+ name);

		System.out.println("Age is "+ age);
		System.out.println("Height is "+ height);

	}

}
