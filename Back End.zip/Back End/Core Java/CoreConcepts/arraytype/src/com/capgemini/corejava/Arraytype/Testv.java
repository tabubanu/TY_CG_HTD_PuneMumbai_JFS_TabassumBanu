package com.capgemini.corejava.Arraytype;

public class Testv {

	public static void main(String[] args) {
		Validator v = new Validator();
		//Custom unchecked Exception
		
		
		
		
		try
		{
			v.verify(14);
		}
		catch(InvalidAgeException in)
		{
			System.err.println(in.getMessage());
		}

	}

}
