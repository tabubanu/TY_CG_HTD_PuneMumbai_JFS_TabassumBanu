package com.capegemini.jpawithhibernetpractice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernatepractice.dto.Channel;

public class InsertChannel {

	public static void main(String[] args) {

		try {
			EntityManager entityManager = null;
			EntityTransaction transaction = null;
			Channel channel = new Channel();
			channel.setChid(1005);
			channel.setChname("Disney");
			channel.setChno(153);
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("test");
			entityManager=entityManagerFactory.createEntityManager();
			transaction=entityManager.getTransaction();
			transaction.begin();
			entityManager.persist(channel);
			System.out.println("channel Inserted");
			transaction.commit();
		} catch (Exception e) {
			System.out.println("Kindly check your input,the given input might already exist");

			
			//e.printStackTrace();
		}
		
	}

}
