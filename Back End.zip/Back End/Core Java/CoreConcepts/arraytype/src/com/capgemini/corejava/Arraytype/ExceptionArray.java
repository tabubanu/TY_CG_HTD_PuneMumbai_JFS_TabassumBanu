package com.capgemini.corejava.Arraytype;

public class ExceptionArray {

	public static void main(String[] args) {
		System.out.println("Main started");
		int [] a = new int[5];

		try
		{
			System.out.println(a[9]);
			/* when there is an exception in first line itself 
			 * then the 
			 * below line will not executed
			 */
			System.out.println(10/0);
		}
		catch(ArrayIndexOutOfBoundsException e )
		{
			System.out.println("Dont cross the array bound");
		}
		catch(ArithmeticException a1)
		{
			System.out.println("Dont divide by 0");
		}
		System.out.println("Main ended");
	}

}
