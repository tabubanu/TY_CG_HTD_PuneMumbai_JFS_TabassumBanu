package com.capgemini.selenium.bean;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetWindowHandle {

		static {
			//System.setProperty("webdriver.chrome.driver", "./selenium/src/main/resource/chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", "./src/main/resource/chromedriver.exe");
			
		}
		
		public static void main(String[] args) {
			WebDriver driver = new ChromeDriver(); // create an object for chrome driver.
			
			//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			//wait.until(ExpecedCondition.titleContains("google"));
			
			driver.get("http://www.google.com");
			//driver.navigate().back();
			String wh = driver.getWindowHandle();
			System.out.println(wh);
			
			driver.get("https://www.naukri.com/");
			Set<String> whs = driver.getWindowHandles();
			System.out.println("number of windows : " +whs.size());
			System.out.println(whs);
			driver.quit();
		}
		
}
