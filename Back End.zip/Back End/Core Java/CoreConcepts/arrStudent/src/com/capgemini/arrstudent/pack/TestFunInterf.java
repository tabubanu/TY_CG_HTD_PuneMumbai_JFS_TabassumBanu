package com.capgemini.arrstudent.pack;

import java.util.function.Function;

public class TestFunInterf {

	public static void main(String[] args) {
		Function<Integer,Integer> f = i->i*i;
		int ans =f.apply(5);
		System.out.println("Result is: "+ans);
	}

}
