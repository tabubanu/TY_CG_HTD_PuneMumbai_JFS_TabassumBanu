package com.capgemini.jpawithhibernetpractice.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernatepractice.dto.Channel;
public class Retrievedata {
	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("test");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Channel";
		Query query = entityManager.createQuery(jpql);
		List<Channel> data = query.getResultList();
		for(Channel channel :data)
		{
			System.out.println("id is: "+ channel.getChid() +", name is: " + channel.getChname() + ", number is: " + channel.getChno());
			
		}
		entityManager.close();
	}

}
