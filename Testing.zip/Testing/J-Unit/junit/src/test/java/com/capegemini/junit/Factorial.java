package com.capegemini.junit;

public class Factorial {
public int factor(int a) {
	int fact = 1;
	for(int i = 1; i<=a ; i++ ) {
		fact = fact*i;	
	}// for
	return fact;
}
}
