package com.capg.corejava.inheritance;

public interface Atm1 {
	void validatecard();
	void getinfo();

}
