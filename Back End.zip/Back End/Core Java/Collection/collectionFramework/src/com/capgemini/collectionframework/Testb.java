package com.capgemini.collectionframework;

import java.util.ArrayList;

public class Testb {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();

		al.add(24);
		al.add("Banu");
		al.add(45.7);
		al.add('f');
		for(Object r : al)
		{
			System.out.println(r);
		}
		
		/*
		 * for(int i=0;i<4;i++) { Object r =al.get(i); System.out.println(r); }
		 */
	}

}
