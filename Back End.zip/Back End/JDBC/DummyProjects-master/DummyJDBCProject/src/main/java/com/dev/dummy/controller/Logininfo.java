package com.dev.dummy.controller;

public class Logininfo {

}
