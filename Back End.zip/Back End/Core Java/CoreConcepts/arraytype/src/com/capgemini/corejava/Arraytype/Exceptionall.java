package com.capgemini.corejava.Arraytype;

public class Exceptionall {

	public static void main(String[] args) {
	
		int [] a = new int [5];
		try {
			System.out.println(10/0);
			System.out.println(a[9]);
		}
		
		

		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("exception arrayoutofbound");
		}
		//catch(Exception e)
		{
			
		}
		
	}

}
