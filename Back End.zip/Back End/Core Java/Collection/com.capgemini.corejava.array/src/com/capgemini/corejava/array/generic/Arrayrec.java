package com.capgemini.corejava.array.generic;

public class Arrayrec {

	public static void main(String[] args) {
		int[] m = {10,20,30,40,50};
		receive(m);
		

	}
	static void receive(int[]a)
	{
		for(int i : a)
		{
			System.out.println(i);
		}
	}

}
