package com.capegemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.onetomany.Pencil;
import com.capgemini.jpawithhibernate.onetomany.PencilBox;

public class TestOnetoMany {

	public static void main(String[] args) {
		EntityManager entityManager = null;
		EntityTransaction transaction = null;
		PencilBox pencilBox = new PencilBox();
		pencilBox.setBoxid(6);
		pencilBox.setName("Natraj");
		Pencil pencil = new Pencil();
		pencil.setPid(18);
		pencil.setColor("Red");
		pencil.setPencilBox(pencilBox);
		
		Pencil pencil1 = new Pencil();
		pencil1.setPid(19);
		pencil1.setColor("Orange");
		pencil1.setPencilBox(pencilBox);
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction transaction1 = null;
		
		

		try {
		emf = Persistence.createEntityManagerFactory("test");
			em= emf.createEntityManager();
			transaction1 = em.getTransaction();
			transaction1.begin();
			//entityManager.persist(person);
			em.persist(pencil);
			em.persist(pencil1);
			System.out.println("enterd");
			
			transaction1.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
			
			System.out.println("Don't enter Duplicate values");

		}em.close();
		

		
	}

}
