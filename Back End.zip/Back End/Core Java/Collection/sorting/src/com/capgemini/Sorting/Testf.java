package com.capgemini.Sorting;

import java.util.LinkedHashSet;
import java.util.TreeSet;
//TreeSet does not take null
public class Testf {

	public static void main(String[] args) {
		TreeSet tr =new TreeSet();
		tr.add(15);
		tr.add(10);
		tr.add(4);
		tr.add(2);
		tr.add(null);
		
		System.out.println("****FOR EACH LOOP******");
		for(Object r :tr)
		{
			System.out.println(r);
			
		}

	}

}
