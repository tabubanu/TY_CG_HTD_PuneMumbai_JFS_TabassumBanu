package com.capgemini.selenium.bean;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class EmailWindow {

	static {
		System.setProperty("webdriver.chrome.driver", "./src/main/resource/chromedriver.exe");	
	}
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); // to avoid noSuchElement Exception
		//enter the URL
		driver.get("https://www.gmail.com");
		//enter the valid username
		driver.findElement(By.id("identifierId")).sendKeys("tabubanu97@gmail.com");
		//click on next
		driver.findElement(By.xpath("//span[text()='Next']")).click();
               		//enter the valid password
		driver.findElement(By.name("password")).sendKeys("@idkat2625");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		
	}
}
