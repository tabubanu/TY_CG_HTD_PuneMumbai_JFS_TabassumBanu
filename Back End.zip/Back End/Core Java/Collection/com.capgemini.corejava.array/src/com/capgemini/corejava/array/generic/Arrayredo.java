package com.capgemini.corejava.array.generic;

public class Arrayredo {

	public static void main(String[] args) {
		double []d = {10.7,23.5,67.8,34.6};
		receive(d);
		

	}

	static void receive(double []a)
	{
		for(double i : a)
		System.out.println(i);
	}
}
