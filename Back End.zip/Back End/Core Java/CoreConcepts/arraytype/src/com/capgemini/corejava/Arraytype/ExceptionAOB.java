package com.capgemini.corejava.Arraytype;

public class ExceptionAOB {
	public static void main(String[]args)
	{
		System.out.println("Main started");
		int []a = new int[3];
		try
		{
			System.out.println(a[7]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Dont cross the array bound");
			
		}
		System.out.println("Main ended");
	}

}
