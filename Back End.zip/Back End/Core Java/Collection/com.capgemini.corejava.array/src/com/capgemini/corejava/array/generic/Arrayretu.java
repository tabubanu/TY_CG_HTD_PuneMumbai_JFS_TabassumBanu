package com.capgemini.corejava.array.generic;

public class Arrayretu {
	public static void main (String[] args)
	{
		int [] i = chinnu();
		for(int k : i)
		{
			System.out.println(k);
		}
		
	}
	static int[] chinnu()
			{
		int[] a = {10,20,30};
		return a ;
		
			}

}
