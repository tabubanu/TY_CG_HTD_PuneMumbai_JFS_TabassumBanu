import { Component } from '@angular/core';

@Component({
    selector: 'app-header',
    // template:`
    // <h1>Header Component is Woring</h1>
    // `,
    // styles:[
    //     `h1 {
    //         background: red;
    //         color: white
    //     }`
    // ]
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent{

}