package com.capg.corejava.inheritance;

public class Casting {

	public static void main(String[] args) {
		Pen p = new Marker();//up casting
		Marker i = (Marker)p;//down casting
		p.cost=20;
		i.write();
		i.size=3.6;
		i.color();
		System.out.println(p.cost);
		System.out.println(i.size);
		
		
	}

}
