package com.capgemini.springcore.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class MessageBean implements InitializingBean, DisposableBean {
	private String message;

	//Getter Setter methods
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void destroy() throws Exception {
		System.out.println("Initializaing Phase");//Initialization happens here.it is a method of InitializingBean
		
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("Destroy Phase"); //destroy happens here.it is a method of DisposableBean
		
	}

}//End of class
