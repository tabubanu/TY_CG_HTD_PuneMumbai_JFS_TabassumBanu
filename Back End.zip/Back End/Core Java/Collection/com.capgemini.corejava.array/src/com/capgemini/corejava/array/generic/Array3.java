package com.capgemini.corejava.array.generic;

public class Array3 {

	public static void main(String[] args) {
		int a[] = {10,5,6,7,8,9,0,1,3};
		for (int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}

}
