package com.capgemini.collectionframework;

import java.util.ArrayList;

public class TestG {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add("Raju");
		al.add(19);
		al.add('M');
		al.add(6.14);
		
		for (Object i : al)
		{
			System.out.println(i);
		}

	}

}
