package com.capgemini.corejava.array.generic;

public class Arraystr {

	public static void main(String[] args) {
		String [] s = {"tabu","banu"};
		receive(s);
		
	}

	static void receive(String [] m)
	{
		for( String j : m)
		{
			System.out.println(j);
		}
	}
}
