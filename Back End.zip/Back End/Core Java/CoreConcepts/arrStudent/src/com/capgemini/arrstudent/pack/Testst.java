package com.capgemini.arrstudent.pack;

import java.util.ArrayList;



public class Testst {

	public static void main(String[] args) {
		 Student s1 = new Student(1,"Manu",80.5,'M');
		 Student s2 = new Student(2,"Arjun",65.5,'M');
		 Student s3 = new Student(3,"Karan",15.05,'M');
		 Student s4 = new Student(4,"Ram",45.5,'M');
		 Student s5 = new Student(5,"Megha",60.0,'F');
		 Student s6 = new Student(6,"anu",77.05,'F');
		 Student s7 = new Student(7,"Mira",30.5,'F');
		 Student s8 = new Student(8,"tanu",25.6,'F');
		 ArrayList <Student> al1 = new ArrayList<Student>();
		    al1.add(s1);
			al1.add(s2);
			al1.add(s3);
			al1.add(s4);
			al1.add(s5);
			al1.add(s6);
			al1.add(s7);
			al1.add(s8);

			Helper1 h1 =new Helper1();
		
		 // h1.displayPassed(al1);
		//h1.displayFailed(al1);
		 // h1.displayFailedBygen(al1);
		  // h1.displayPassedBygen(al1);
		  
		  h1.displayTopper(al1);
		 
			
			
			}

}
