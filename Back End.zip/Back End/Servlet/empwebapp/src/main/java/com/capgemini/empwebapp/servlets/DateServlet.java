package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DateServlet extends HttpServlet {
	public DateServlet() {
		System.out.println("Its Instantiation Phase!");
	}//End of Instantiation
	@Override
	public void init() throws ServletException {
		System.out.println("Init Phase.....");
	}//End of init
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Its Service Phase...");//Service Phase of Http Servlet can have any doXXX methods

		
		Date date = new Date();
		ServletContext context = getServletContext();
		String companyNameVal = context.getInitParameter("companyName");
		
//		resp.setHeader("refresh", "1");
		resp.setContentType("text/html");//what type of response its going to get.
		
		PrintWriter out = resp.getWriter();
		out.println("<html>");
//		out.println("<head>");
//		out.println("<meta http-equiv='refresh' content='1'>");
//		out.println("</head");
		out.println("<body>");
		out.println("<h1>Current System Date & Time-<br>");
		out.println(date + "</h1>");
		out.println("<h2>Context Param Value is - "+ companyNameVal + " </h2>");
		out.println("</body>");
		out.println("</html>");
		
	
	}//End of doGet()
	@Override
	public void destroy() {
		System.out.println("Its Destroy Phase...");
	}//End of Destroy
}//End of Class
