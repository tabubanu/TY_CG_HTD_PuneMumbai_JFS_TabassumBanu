package com.capgemini.jdbclogin.controller;

import java.util.Scanner;

import com.capgemini.jdbclogin.dao.UserDAO;
import com.capgemini.jdbclogin.factory.UserFactory;
import com.capgemini.jdbclogin.myfile.UserBean;



public class GetInfo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		UserDAO dao = UserFactory.getInstance();
		System.out.println("Enter the user id.......");
		UserBean password = dao.getInfo(sc.toString());
		UserBean user = dao.getInfo(sc.nextInt());
		if(user!=null)
		{
			System.out.println(user);
		}
		else
		{
			System.out.println("Something went wrong........");
		}
		if(password!=null)
		{
			System.out.println(password);
		}
		else
		{
			System.out.println("Something went wrong........");
		}
		sc.close();
	}




}
