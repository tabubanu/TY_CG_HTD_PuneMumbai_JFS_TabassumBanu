package com.capgemini.corejava.Arraytype;

public class TestA {
	public static void main(String []args)
	{
		double[] d= {2.2,4.6,7.8,7.9};
		
		Mouse m = new Mouse();
		m.walk(d);
		
		int [] b = {3,5,7,8};
		m.run(b);
		
	}
	

	
}
