package com.capgemini.corejava.Arraytype;

public class Testc {

	public static void main(String[] args) {
		System.out.println("Main Started");
		paytm p = new paytm();
		
		
		try
		{
			p.book();
		}
		catch(ArithmeticException e )
		{
			System.out.println("Exception cought at main ");
		}
		
		System.out.println("main Ended");
	}

}
