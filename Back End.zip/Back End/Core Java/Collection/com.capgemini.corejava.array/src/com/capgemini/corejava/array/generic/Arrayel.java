package com.capgemini.corejava.array.generic;

public class Arrayel {

	public static void main(String[] args) {
		double a[] = new double[4];
		a[2]=100;
		for (double d : a)
		{
			System.out.println(d);
		}

	}

}
