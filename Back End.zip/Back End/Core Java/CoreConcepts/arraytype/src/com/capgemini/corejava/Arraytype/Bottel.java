package com.capgemini.corejava.Arraytype;

import java.io.File;
import java.io.IOException;



public class Bottel {
	void open() throws IOException, ClassNotFoundException
	{
		File f = new File("tabu.txt");
		f.createNewFile();
		
		Class.forName("com.capegemini.corejava.Arraytype.Bottel");
	}
	

}
