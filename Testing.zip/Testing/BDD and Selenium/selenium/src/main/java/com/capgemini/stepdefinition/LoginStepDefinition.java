package com.capgemini.stepdefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.formatter.model.Background;

public class LoginStepDefinition {

	static {
		System.setProperty("webdriver.chrome.driver", "./src/main/resource/chromedriver.exe");
	}
	WebDriver driver;
	
	
	@Given("^the user has loaded the application in the browser$")
	public void the_user_has_loaded_the_application_in_the_browser() throws Throwable {
		driver = new ChromeDriver();
		driver.get("http://demo.actitime.com/");
	}

	@When("^the user enter the valid username$")
	public void the_user_enter_the_valid_username() throws Throwable {
		driver.findElement(By.id("username")).sendKeys("admin");
	}

	@When("^the user enter valid password$")
	public void the_user_enter_valid_password() throws Throwable {
		driver.findElement(By.name("pwd")).sendKeys("manager");
	}

	@When("^the user clicks on the login button$")
	public void the_user_clicks_on_the_login_button() throws Throwable {
		driver.findElement(By.xpath("//div[text()='Login ']")).click();
	}

	@Then("^the dashboard page will be displayed$")
	public void the_dashboard_page_will_be_displayed() throws Throwable {
		
		String actual = driver.getTitle();
		String expected = "actiTIME - Login";
		Assert.assertEquals(expected, actual);
		Thread.sleep(4000);
		
	}
	    @When ("^the user enter invalid password$")
		public void the_user_enter_invalid_password() throws Throwable {
			driver.findElement(By.name("pwd")).sendKeys("asdfgh");
		}

		@Then("^the user should be in the same page$")
		public void the_user_should_be_in_the_same_page() throws Throwable {
			String actual = driver.getTitle();
			String expected = "actiTIME - Login";
			Assert.assertEquals(expected, actual);
			Thread.sleep(4000);
		}


@When("^the user enters \"([^\"]*)\" in the username testbox$")
public void the_user_enters_in_the_username_testbox(String arg1) throws Throwable {
	driver.findElement(By.id("username")).sendKeys(arg1);
}

@When("^the user enters \"([^\"]*)\" in the password textbox$")
public void the_user_enters_in_the_password_textbox(String arg1) throws Throwable {
	driver.findElement(By.name("pwd")).sendKeys(arg1);
}



	}

