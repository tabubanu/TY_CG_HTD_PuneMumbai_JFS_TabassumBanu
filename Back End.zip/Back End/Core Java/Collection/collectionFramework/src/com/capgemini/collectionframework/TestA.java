package com.capgemini.collectionframework;

import java.util.ArrayList;

public class TestA {
public static void main(String[]args)
{
	ArrayList al= new ArrayList();
	al.add(24);
	al.add("tabu");
	al.add(2.9);
	al.add('f');
	
	for(int i=0;i<4;i++)
	{
		Object r = al.get(i);
		System.out.println(r);
	}
	
}
}
