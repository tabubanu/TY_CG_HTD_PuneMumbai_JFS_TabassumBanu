package com.capgemini.corejava.Arraytype;

public class Amount {
	void check (int val) throws InvalidLimitException
	{
		if(val>40000)
		{
			throw new InvalidLimitException();
		}
	}

}
