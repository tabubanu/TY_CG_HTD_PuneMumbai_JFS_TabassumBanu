package com.capgemini.collectionframework;

import java.util.ArrayList;
import java.util.Iterator;

public class Testc {

	public static void main(String[] args) {
		
		ArrayList al= new ArrayList();
		al.add(23);
		al.add("Tabassum");
		al.add(29.0);
		al.add('t');
		
		Iterator it = al.iterator();
		while(it.hasNext())
		{
		Object r = it.next();
		System.out.println(r);
		}	
	}
}


/*Object t = it.next();
Object i = it.next();
Object k = it.next();


System.out.println(t);
System.out.println(i);
System.out.println(k);*/
