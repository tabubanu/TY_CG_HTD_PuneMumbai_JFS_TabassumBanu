package com.capgemini.jdbc;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;


public class JDBCRetrivalAll {

	public static void main(String[] args) {
		Connection conn= null;
		FileReader reader=null;
		Properties prop=null;
		PreparedStatement pstmt = null;
		Scanner sc =new Scanner(System.in);
		ResultSet rs = null;
		try {
			
			//Load The Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loading");
			System.out.println("*****************");
			
			/*
			 * java.sql.Driver driver= new com.mysql.jdbc.Driver();
			 * DriverManager.registerDriver(driver);
			 * System.out.println("Driver Loaded..... "); 
			 * System.out.println("***********");
			 */
			
			reader = new FileReader("C:\\Users\\my\\Desktop\\db.properties");
			 prop = new Properties();
			prop.load(reader);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		//Get the Connection
		String dbUrl="jdbc:mysql://localhost:3306/capg_db";
		try {
			conn = DriverManager.getConnection(dbUrl, prop);
			System.out.println("Connection Established...........");
			System.out.println("-------------------------------------");
			
			//Issue the SQL Query
			String query = "SELECT * FROM users_info where userid=  ?";
			pstmt = conn.prepareStatement(query);
			/*
			 * 
			 * 
			 * 
			 */
			System.out.println("Enter the User Id....");
			 pstmt.setInt(1,sc.nextInt());
			rs = pstmt.executeQuery();
			
			//Process the results
			if(rs.next())
			{
				System.out.println("User Id: "+rs.getInt(1));
				System.out.println("User Name: "+rs.getString(2));
				System.out.println("User Email: "+rs.getString(3));
				System.out.println("Password:"+rs.getString(4));
			}
			else
			{
				System.out.println("Something went wrong");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			if(conn != null)
			{
				try {
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			
			//Close all the JDBC Objects
			if(pstmt!=null)
			{
				try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
			sc.close();
		}
		

	}

}
