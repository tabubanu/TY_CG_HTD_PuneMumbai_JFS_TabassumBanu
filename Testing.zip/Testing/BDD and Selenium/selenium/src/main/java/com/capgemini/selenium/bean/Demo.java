package com.capgemini.selenium.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo {
 
	static {
		//System.setProperty("webdriver.chrome.driver", "./selenium/src/main/resource/chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", "./src/main/resource/chromedriver.exe");
		
	}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver(); // create an object for chrome driver.
		driver.get("https://www.seleniumhq.org/");
		driver.manage().window().maximize(); // maximize is to maximize your window
		driver.navigate().to("http://www.google.com");
		driver.navigate().back();
		String title = driver.getTitle();
		System.out.println(title);
		driver.close();
	}
	
}
