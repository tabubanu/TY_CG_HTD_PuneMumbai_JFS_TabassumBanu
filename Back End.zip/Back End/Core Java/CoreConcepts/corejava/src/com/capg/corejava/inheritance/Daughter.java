package com.capg.corejava.inheritance;

public class Daughter extends Father implements InterfaceExample1{

	String dname = "Sansa";
	public static void main(String[] args) {
		new Daughter().printname();
		new Daughter().display();
		new Daughter().show();
		

	}
	@Override
	public void printname()
	{
		System.out.println(dname+" "+ fname +" "+lastname);
		super.printname();
	}
	

	@Override
	public void display()
	{
		System.out.println("display method in son");
	}
	@Override
	public void show()
	{
		System.out.println("show method in son");
	}


}
