export class Car{
    constructor(
        public brand : string,
        public imgURL : string,
        public price : number,
        public specs : string
    ){}
}