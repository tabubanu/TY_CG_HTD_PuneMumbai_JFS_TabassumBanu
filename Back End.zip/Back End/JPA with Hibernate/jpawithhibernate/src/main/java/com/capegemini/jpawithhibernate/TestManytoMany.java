package com.capegemini.jpawithhibernate;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.javawithhibernate.manytomany.Course;
import com.capgemini.javawithhibernate.manytomany.Student;

public class TestManytoMany {

	public static void main(String[] args) {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction transaction = null;

		
		Course course = new Course();
		course.setCid(4);
		course.setCname("Jdbc");
		

		Course course1 = new Course();
		course1.setCid(5);
		course1.setCname("SQL");
		ArrayList <Course> al = new ArrayList<Course>();
		al.add(course);
		al.add(course1);
		
		Student student =new Student();
		student.setSid(5);
		student.setSname("neha");
	    student.setCourse(al);
	    
		
		
		try {
			emf = Persistence.createEntityManagerFactory("test");
			em = emf.createEntityManager();
			transaction = em.getTransaction();
			transaction.begin();
			//em.persist(student);
			Course course2 =em.find(Course.class, 1);
			course2.getStudent().get(0).getSid();
			transaction.commit();
			
			
		}
		catch(Exception e)
		{
		  e.printStackTrace();
		  transaction.rollback();
		  System.out.println("Enter correct value");
		  
		}
		
	}

}
