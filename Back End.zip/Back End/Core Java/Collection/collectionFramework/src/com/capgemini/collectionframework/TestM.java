package com.capgemini.collectionframework;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class TestM {

	public static void main(String[] args) {
		LinkedList<String> ll= new LinkedList<String>();
		
		ll.add("tabu");
		ll.add("banu");
		ll.add("di");
		ll.add("fifa");
		ll.add("lifA");
		
		System.out.println("********for loop");
		for (int i =0;i<=5;i++)
		{
			
			String r = ll.get(i);
			System.out.println(r);
		}
		System.out.println("*********for each");
		for(String i : ll)
		{
			System.out.println(i);
		}
		
		
		System.out.println("*********Iterator");
		
		Iterator<String> it = ll.iterator();
		
		while(it.hasNext())
		{
			String k = it.next();
			System.out.println(k);
			
		}
		System.out.println("***************listiterator");
		
		ListIterator<String> li = ll.listIterator();
		while(li.hasNext())
		{
		String r = li.next();
		System.out.println(r);
		}
		System.out.println("<---------------- Backward");
		while(li.hasPrevious())
		{
		Object r = li.previous();
		System.out.println(r);
		}
		
		
	}

}

