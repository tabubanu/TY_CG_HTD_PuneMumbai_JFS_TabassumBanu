package com.capg.corejava.inheritance;

public class Test1 {

	public static void main(String[] args) {
		Driver d=new Driver();
		Car i = new Car();
		d.receive(i);
		

	}

}
