package com.capgemini.Sorting;

public class Student implements Comparable<Student>{
	int id;
	String name;
	double percentage;
	public Student(int id, String name, double percentage) {
		
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}
	//Logic to sort students by ID
	/*@Override
	public int compareTo(Student s) {
		if(this.id>s.id)
		{
			return 1;
		}
		else if(this.id<s.id)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	*/
	/*@Override
	public int compareTo(Student s) {
		if(this.percentage>s.percentage)
		{
			return 1;
		
	
	}
		else if(this.percentage<s.percentage)
		{
			return -1;
			
		}
	
		else
		{
			return 0;
		}*/
	/*
	 * @Override public int compareTo(Student s) {
	 * 
	 * return this.name.compareTo(s.name)*-1;//for descending order }
	 */
	/*
	 * @Override public int compareTo(Student s1) {
	 * 
	 * return this.name.compareTo(s1.name);
	 * }
	 *for ascending order 
	 */
	/*
	 * @Override public int compareTo(Student s) { String k =this.name; String r =
	 * s.name;
	 * 
	 * int res = k.compareTo(r); return res;
	 * 
	 * }
	 */
	@Override
	public int compareTo(Student s) {
		Double k = this.percentage;
		Double t =s.percentage;
		return k.compareTo(t);
	}
	
	

}
