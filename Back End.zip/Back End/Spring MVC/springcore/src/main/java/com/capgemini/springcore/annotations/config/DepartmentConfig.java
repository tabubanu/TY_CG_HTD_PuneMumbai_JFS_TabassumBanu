package com.capgemini.springcore.annotations.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.springcore.annotations.beans.DepartmentBean;

@Configuration
public class DepartmentConfig {

	@Bean(name = "dev")
	//@Primary
	public DepartmentBean getDevDept() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(1001);
		bean.setDeptName("Development");
		return bean;
	}

	@Bean(name = "testing")
	public DepartmentBean getTestingDept() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(1002);
		bean.setDeptName("Testing");
		return bean;
	}

	@Bean(name = "hr")
	public DepartmentBean getHRDept() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(1003);
		bean.setDeptName("HR");
		return bean;
	}
}// End of class
