package com.capg.corejava.inheritance;

public class Bingo implements Chips {

	@Override
	public void open() {
		// TODO Auto-generated method stub

	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub

	}

}
