package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCDelete {
	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement pstmt= null;
		Scanner sc  = new Scanner(System.in);
		//Load the Driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded.........");
			System.out.println("************************");
			//Get the database connection
			//String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			
			
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?";
			System.out.println("Enter the username and password");
			String user = sc.nextLine();
			String password = sc.nextLine();
			
			conn = DriverManager.getConnection(dbUrl);
			System.out.println("Connection established.......");
			System.out.println("************");
			
			//Issue SQL query via connection
			//String query = "UPDATE users_info SET username=?,email=?,password=? where userid=?";
			
			String query = "DELETE FROM users_info  where userid=? ";
			// each '?' represents each column
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter userid...");
			pstmt.setInt(2, Integer.parseInt(sc.nextLine()));
			
			
			
			
			
			/*
			 * System.out.println("Enter username..."); pstmt.setString(1, sc.nextLine());
			 */
			
			
			  System.out.println("Enter email..."); pstmt.setString(1, sc.nextLine());
			  System.out.println("Enter password..."); pstmt.setString(3, sc.nextLine());
			 
			int count = pstmt.executeUpdate();
			
			
			
			if (count>0)
			{
				System.out.println("Data Deleted.......");
			}

		
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		finally {
			if(conn != null)
			{
				try {
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			if(pstmt!=null)
			{
				try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
			sc.close();
		
		}
		
		

	}

}
