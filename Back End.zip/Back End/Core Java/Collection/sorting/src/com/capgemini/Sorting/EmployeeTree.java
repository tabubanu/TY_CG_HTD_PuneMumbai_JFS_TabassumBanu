package com.capgemini.Sorting;

public class  EmployeeTree implements Comparable<EmployeeTree> {
	
	int id;
	String name;
	Double salary;
	
	
	public EmployeeTree(int id, String name, Double salary) {
		
		this.id = id;
		this.name = name;
		this.salary = salary;
	}


	@Override
	public int compareTo(EmployeeTree e) {
		Integer k = e.id;
		Integer p = this.id;
		
		return k.compareTo(p);
	}
	

}
