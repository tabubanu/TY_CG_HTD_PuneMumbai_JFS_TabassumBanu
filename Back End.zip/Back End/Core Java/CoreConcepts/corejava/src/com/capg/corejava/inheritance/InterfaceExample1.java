package com.capg.corejava.inheritance;

public interface InterfaceExample1 {
	public void display();
	public void show();

}
