package com.capgemini.stringexp.one;

public class TestA {

	public static void main(String[] args) {

		StringBuilder sb = new StringBuilder();
		sb.append("Amit");
		System.out.println(sb);
		
		
	}
	
}
