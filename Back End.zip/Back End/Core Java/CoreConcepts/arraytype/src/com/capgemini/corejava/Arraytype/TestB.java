package com.capgemini.corejava.Arraytype;

public class TestB {

	public static void main(String[] args)
	{
		System.out.println("Main method started");
		
	
	try
	{
		System.out.println(10/2);
		System.out.println(10/0);
		System.out.println("Hi");
		System.out.println("Keep Smiling");
	}
	catch(ArithmeticException a)
	{
		System.out.println("Dont divivde with 0");
		
	}
	
	

	System.out.println("Main method ");
}
}
