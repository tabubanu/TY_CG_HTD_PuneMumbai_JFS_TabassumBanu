package com.capegemini.junit;

public class Calculator {

	public int add(int a, int b) {
		return a+b;
	}// add()
	
	public int div(int a, int b) {
		return a/b;
	}// div()
	
	public int mul (int a, int b) {
		return a*b;
	}// mul
	
	public int sub (int a, int b) {
		return a-b;
	}// sub
	
	public int factor(int a) {
		int fact = 1;
		for(int i = 1; i<=a ; i++ ) {
			fact = fact*i;	
		}// for
		return fact;
	}
	
}// End of class
