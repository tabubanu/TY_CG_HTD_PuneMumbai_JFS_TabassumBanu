package com.capgemini.corejava.array.generic;

public class Array {

	public static void main(String[] args) {
		double[] a = new double[4];
		a[0]= 29.8;
		a[3]= 5;
		a[2]=6.4;
		a[1]=9;
		System.out.println(a[0]);
		
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
			
		String[] s = new String[4];
		s[0]="tabu";
		s[1]="banu";
		s[2]= "diksha";
		s[3]= "ameya";
		System.out.println(s[0]);
		System.out.println(s[1]);
		System.out.println(s[2]);
		System.out.println(s[3]);
		

	}

}
