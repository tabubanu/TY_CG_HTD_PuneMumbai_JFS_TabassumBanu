package com.capgemini.empwebapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;


import com.capgemini.empwebapp.beans.EmployeeInfoBean;

public class EmployeeDAOJpaImpl implements EmployeeDAO {

	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("test");
	@Override
	public EmployeeInfoBean getEmployee(int empId) {
		
		EntityManager em = emf.createEntityManager();
		EmployeeInfoBean employeeInfoBean = em.find(EmployeeInfoBean.class, empId);
		em.close();
//		emf.close();
		
		return employeeInfoBean;
	}//End of getEmployee()

	@Override
	public EmployeeInfoBean authenticate(int empId, String pwd) {
		EntityManager manager = emf.createEntityManager();
//		EmployeeInfoBean employeeInfoBean = manager.find(EmployeeInfoBean.class, empId);
//		manager.close();
//		if(pwd.equals(employeeInfoBean.getPassword())) {
//			return true;
//		}else {
//			return false;	
//		}
		String jpql = "from EmployeeInfoBean where empId = :empId and password = :pwd";
		Query query = manager.createQuery(jpql);
		query.setParameter("empId", empId);
		query.setParameter("pwd", pwd);
		EmployeeInfoBean employeeInfoBean = null;
		try {
			employeeInfoBean = (EmployeeInfoBean) query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return employeeInfoBean;
	}//End of authenticate()

	@Override
	public boolean addEmployee(EmployeeInfoBean employeeInfoBean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdded = false;
		try {
			tx.begin();
			manager.persist(employeeInfoBean);//Stores the object
			tx.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		manager.close();
		
		return isAdded;
	}//End of addEmployee

	@Override
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
		// TODO Auto-generated method stub
		return false;
	}
}//End of Class
