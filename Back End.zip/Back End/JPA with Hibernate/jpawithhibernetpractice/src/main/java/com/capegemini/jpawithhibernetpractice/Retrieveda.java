package com.capegemini.jpawithhibernetpractice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernatepractice.dto.Channel;
public class Retrieveda {

	public static void main(String[] args) {

		Channel channel = new Channel();
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Channel ch=entityManager.find(Channel.class,1002);//find(entityname.class,primary key)
		System.out.println("ID---"+ch.getChid());
		System.out.println("Name---"+ch.getChname());
		System.out.println("Number---"+ch.getChno());	
	}

}
