package com.capgemini.corejava.Arraytype;

import java.util.Scanner;

public class Anyclas {

	public static void main(String[] args) {
		
		try(Scanner sc= new Scanner(System.in))
	{
		System.out.println("enter the age");
		int age = sc.nextInt();
		
		System.out.println("Age is "+age);
				}

	}

}
