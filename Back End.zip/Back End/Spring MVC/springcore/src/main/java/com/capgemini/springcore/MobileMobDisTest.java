package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MobileBean;

public class MobileMobDisTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("mobileConfig.xml");
		MobileBean mobileBean = context.getBean("mobile", MobileBean.class);
		
		System.out.println("Mobile Brand : " +mobileBean.getBrandName() );
		System.out.println("Mobile Model : " + mobileBean.getModelName());
		System.out.println("MobileModel : " + mobileBean.getPrice());
		System.out.println("MobileDisplay Size : " + mobileBean.getMobileDis().getDisplaySize());
		System.out.println("MobileDisplay Resolution : " + mobileBean.getMobileDis().getResolution());

		
	}

}
