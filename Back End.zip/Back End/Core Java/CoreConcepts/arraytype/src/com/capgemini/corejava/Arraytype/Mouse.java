package com.capgemini.corejava.Arraytype;

public class Mouse {

	void walk(double[] a)
	{
		for (double i :a)
		{
			System.out.println(i);
		}
	}

	void run(int[]b)
	{
		for(int i = 0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
	}
}
