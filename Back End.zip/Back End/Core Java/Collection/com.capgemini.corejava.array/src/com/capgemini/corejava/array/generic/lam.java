package com.capgemini.corejava.array.generic;

public class lam {

}
