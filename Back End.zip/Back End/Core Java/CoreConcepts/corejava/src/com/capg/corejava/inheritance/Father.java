package com.capg.corejava.inheritance;

public class Father extends Grandfather {
	String fname = "Eddard";

	public static void main(String[] args) {
		new Father().printname();
		new Father().printname1();

	}
	//@Override

	public void printname1()
	{
		System.out.println(fname+ " "+name+" "+lastname);
		super.printname();
	}
}
