package com.capgemini.corejava.array.generic;

interface Square {
	int square(int a);

}
public class Lamdasquare
{
	public static void main(String[]args) {
		Square s =  a -> a * a;
		int res = s.square(10);
		System.out.println("result is "+res);
	}
}
