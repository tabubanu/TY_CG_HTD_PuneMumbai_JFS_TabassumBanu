package com.capegemini.junit;

public class Sum {
	public int add(int a, int b) {
		return a+b;
	}// End of add()

	public int add(int a, int b, int c) {
		return a+b+c;
	}// Enf of add()
}// End of class
