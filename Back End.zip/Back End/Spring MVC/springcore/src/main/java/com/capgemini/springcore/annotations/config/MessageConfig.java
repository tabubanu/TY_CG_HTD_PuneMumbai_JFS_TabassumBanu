package com.capgemini.springcore.annotations.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.capgemini.springcore.annotations.beans.MessageBean;

@Configuration // the spring will come to know that this is a configuration class
public class MessageConfig {

	@Bean // the spring will know that is a config method 
	@Scope ("prototype")
	public MessageBean getMessageBean() {
		MessageBean messageBean = new MessageBean();
		messageBean.setMessage("Hello World!!!");
		return messageBean;
	}// End of getMessageBean

}// End of class
