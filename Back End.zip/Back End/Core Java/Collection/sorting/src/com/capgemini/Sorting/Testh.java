package com.capgemini.Sorting;


import java.util.Iterator;
import java.util.LinkedHashSet;

public class Testh {

	public static void main(String[] args) {
	
		LinkedHashSet<Employee> lhs =new LinkedHashSet<Employee>();
		Employee e1 = new Employee(1,"Tabu",1200.69);
		Employee e2 = new Employee(2,"Sne",1430.69);
		Employee e3 = new Employee(3,"edw",15009.69);
		Employee e4 = new Employee(4,"rock",1400.90);
		Employee e5 = new Employee(5,"popper",1500.69);
		lhs.add(e1);
		lhs.add(e2);
		lhs.add(e3);
		lhs.add(e4);
		lhs.add(e5);
		
		System.out.println("********Using For Each loop*******");
		/*
		 * for(Employee r :lhs) { System.out.println("Name of Employee:"+r.name);
		 * System.out.println("Name of ID:"+r.id);
		 * System.out.println("Name of Salary:"+r.salary);
		 * System.out.println("*********************");
		 * 
		 * }
		 */
		System.out.println("********Using Iterator*******");
		Iterator<Employee> it = lhs.iterator();
		while(it.hasNext())
		{
			Employee r = it.next();
			System.out.println("Name of Employee:"+r.name);
			System.out.println("Name of ID:"+r.id);
			System.out.println("Name of Salary:"+r.salary);
			System.out.println("*********************");
			
		}

		
		

	}

}
