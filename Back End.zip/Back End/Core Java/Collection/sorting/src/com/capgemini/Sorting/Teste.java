package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class Teste {

	public static void main(String[] args) {
		LinkedHashSet<Double> hs =new LinkedHashSet<Double>();
		hs.add(11.5);
		hs.add(1.5);
		hs.add(5.3);
		hs.add(9.0);
		
		System.out.println("****FOR EACH LOOP******");
		for(Double r :hs)
		{
			System.out.println(r);
			
		}
		System.out.println("****ITERATOR******");
		Iterator<Double> it = hs.iterator();
		while(it.hasNext())
		{
			Double r = it.next();
			System.out.println(r);
		}

	}

}
