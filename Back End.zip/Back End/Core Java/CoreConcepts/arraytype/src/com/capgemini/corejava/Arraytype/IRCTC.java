package com.capgemini.corejava.Arraytype;

public class IRCTC {
 
	void confirm()
	{
		System.out.println("Confirm Started");
		try {
		System.out.println(10/0);
		
		}
		catch(ArithmeticException e )
		{
			System.out.println("Exception at confirm");
		}
		/* whenever 
		 * 
		 */
		
		
		System.out.println("confirm Ended");
	}
}
