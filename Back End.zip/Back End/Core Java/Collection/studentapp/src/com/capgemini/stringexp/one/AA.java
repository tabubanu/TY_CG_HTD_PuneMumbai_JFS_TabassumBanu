package com.capgemini.stringexp.one;

public interface AA {

	static void run() {
		
	}
	
}
