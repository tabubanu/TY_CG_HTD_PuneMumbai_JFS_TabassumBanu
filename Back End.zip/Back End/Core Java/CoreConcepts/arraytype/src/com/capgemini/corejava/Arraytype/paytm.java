package com.capgemini.corejava.Arraytype;

public class paytm {
	void book()
	{
		System.out.println("Book started");
		IRCTC i = new IRCTC();
		
		
		
		try
		{
			i.confirm();
		}
		catch(ArithmeticException e )
		{
			System.out.println("Exception cought at book ");
		}
		
		
		
		System.out.println("Book ended");
	}

}
