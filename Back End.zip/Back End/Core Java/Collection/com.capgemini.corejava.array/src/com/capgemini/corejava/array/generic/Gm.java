package com.capgemini.corejava.array.generic;
interface Good
{
void s(); 	
}
public class Gm {
	public static void main (String[]args)
	{
		Good g = ()-> System.out.println("good Mornning");
		g.s();
		
	}
	

}
