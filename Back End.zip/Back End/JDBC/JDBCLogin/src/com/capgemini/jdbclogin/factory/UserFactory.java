package com.capgemini.jdbclogin.factory;

import com.capgemini.jdbclogin.dao.UserDAO;
import com.capgemini.jdbclogin.dao.UserDAOJDBCImpl;

public class UserFactory {
	private UserFactory()
	{
		
	}
	public static UserDAO getInstance()
	{
		UserDAO dao = new UserDAOJDBCImpl();
		return dao;
	}

}



