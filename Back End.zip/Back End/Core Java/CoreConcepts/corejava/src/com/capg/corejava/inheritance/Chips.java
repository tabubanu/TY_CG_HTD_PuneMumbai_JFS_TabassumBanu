package com.capg.corejava.inheritance;

public interface Chips {
	void open();
	void eat();
	

}
