package com.capgemini.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts {
	static Pattern pattern;
	static Matcher matcher;

	public static void main(String[] args) {
		pattern = Pattern.compile("\\d");
		//d for digit only checks for the single digit
		
		matcher = pattern.matcher("1");
		//matcher() is a method used to create an object for matcher
		System.out.println("pattern \\d:"+matcher.matches());
		//matches() is a method which is used to match the pattern amd matcher
				
		pattern = Pattern.compile("\\d+");
		//d+ for digit checks for the more than one digit
		
		matcher = pattern.matcher("12446262575");
		// to create object for matcher class
		System.out.println("pattern \\d:"+matcher.matches());
		
		pattern = Pattern.compile("\\D");
		//D ensures that whatever the data entered is not digit and 
		// the it checks for only one value
		
		
		matcher = pattern.matcher("1");
		System.out.println("pattern \\D:"+matcher.matches());
		
		pattern = Pattern.compile("\\D+");
		//D ensures that whatever the data entered is not digit and 
		// the it checks for only one value
		
		
		matcher = pattern.matcher("2143215");
		System.out.println("pattern \\D+:"+matcher.matches());
		
		pattern = Pattern.compile("\\w");
		// w matches only one character
		
		matcher = pattern.matcher("A");
		System.out.println("pattern\\w:"+matcher.matches());
		
		pattern = Pattern.compile("\\W");
		// W matches only one value and it ensures that 
		//it does not contain any characters
		
		matcher = pattern.matcher("A");
		System.out.println("pattern\\W:"+matcher.matches());
		
		pattern = Pattern.compile("\\W+");
		// W+ matches more than one value and it ensures that 
		//it does not contain any characters
		
		matcher = pattern.matcher("Aewfg");
		System.out.println("pattern\\W+:"+matcher.matches());
		
		pattern = Pattern.compile("\\w+");// w+ matches more than one character
		
		matcher = pattern.matcher("Admsfrgvkr");
		System.out.println("pattern\\w:"+matcher.matches());
		Pattern pat3 = Pattern.compile("\\d{0}");
		Matcher mat3 = pat3.matcher("");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{0}:"+mat3.matches());
		
		Pattern pat4 = Pattern.compile("\\d{0}");
		Matcher mat4 = pat4.matcher("1");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{0}:"+mat4.matches());
	
		Pattern pat5 = Pattern.compile("\\d{1,9}");
		Matcher mat5 = pat5.matcher("123456789");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{0}:"+mat5.matches());
		
		Pattern pat6 = Pattern.compile("\\d{1,9}");
		Matcher mat6 = pat6.matcher("");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{1,9}:"+mat6.matches());
		
		Pattern pat7 = Pattern.compile("\\d{1,9}");
		Matcher mat7 = pat7.matcher("1234567890");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{1,9}:"+mat7.matches());
		
	}

}
