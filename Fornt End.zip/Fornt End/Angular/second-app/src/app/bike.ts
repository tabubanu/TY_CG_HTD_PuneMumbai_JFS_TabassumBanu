export class Bike {
    constructor(
        public brand: string,
        public imgURL: string,
        public model: string,
        public price: number,
        public specs: string
    ){}
       

    
}
