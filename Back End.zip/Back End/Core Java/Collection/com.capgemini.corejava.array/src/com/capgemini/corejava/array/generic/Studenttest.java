package com.capgemini.corejava.array.generic;

public class Studenttest {

	public static void main(String[] args) {
		Student [] s = new Student [4];
		
		Student s0 = new Student (1,"tabu",78.4);
		Student s1 = new Student (2,"tabu",78.4);
		Student s2 = new Student (3,"tabu",78.4);
		Student s3 = new Student (4,"tabu",78.4);
		s[0]= s0;
		s[1]= s1;
		s[2]= s2;
		s[3]= s3;
		receive(s);

	}
	static void receive(Student [] ar)
	{
		for(Student k : ar)
		{
			System.out.println(k.id);
			System.out.println(k.name);
			System.out.println(k.percentage);
		}
	}


			
		}
	


