package com.capgemini.corejava.Arraytype;
import java.io.File;
import java.io.IOException;

public class Testg {

	public static void main(String[] args) throws IOException {
		File f = new File("vikas.txt");
		f.createNewFile();

	}

}
