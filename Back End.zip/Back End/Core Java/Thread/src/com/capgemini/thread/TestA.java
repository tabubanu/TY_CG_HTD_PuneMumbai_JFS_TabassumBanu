package com.capgemini.thread;

public class TestA {

	public static void main(String[] args) {
		System.out.println("Main Started");
		Pen p = new Pen();
		//p.setDaemon(true);
		p.start();
		
		Pen t = new Pen();
		//p.setDaemon(true);
		t.start();
		
		try {
			//Thread.sleep(2000);
			
			  p.join(); t.join();
			 
		} 
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		System.out.println("Main Ended");

	}

}
