package com.capg.corejava.inheritance;

public class Pen {
	int cost;
	void write()
	{
		System.out.println("Start writing ");
	}

}
