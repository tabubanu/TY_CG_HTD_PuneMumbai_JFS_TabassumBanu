package com.capgemini.arrstudent.pack;

import java.util.function.Function;

public class Testfun {

	public static void main(String[] args) {
		 Function <Integer,Student> s = i->{
		
			 Student m = new Student();
			 m.id= i;
			 return m;
		 };
		 Student m = s.apply(6);
		 System.out.println("Name is:" + m.name);
			System.out.println("ID is:" + m.id);
			System.out.println("Percentage is:" + m.percentage);
		 
		 
		
	}

}
