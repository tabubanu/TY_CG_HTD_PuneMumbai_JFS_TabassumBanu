package com.capgemini.corejava.Arraytype;

public class PVR {
	void confirm()
	{
		System.out.println("cofirm started");
		try {
			System.out.println(10/2);
		}
		catch(ArithmeticException a)
		{
			System.out.println("Exception caught at confirm pvr");
			throw a;
			
		}
		finally 
		{
			System.out.println("confirm ended");
		}
	}

}
