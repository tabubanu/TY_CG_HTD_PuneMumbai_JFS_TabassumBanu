package com.capegemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumTest {

	@Test
	public void testAdd() {
		Sum s = new Sum();
		int k = s.add(10, 5);
		int m = s.add(10, 10, 10);
		assertEquals(15, k);
		assertEquals(30, m);
	}// End of testAdd() 

	
}// End of class
