package com.capgemini.collectionframework;

import java.util.ArrayList;

public class TestE {

	public static void main(String[] args) {
		ArrayList al= new ArrayList();
		al.add(23);
		al.add("Tabassum");
		al.add(29.0);
		al.add('t');
		System.out.println(al);

	}

}
