package com.capgemini.jdbclogin.dao;

import com.capgemini.jdbclogin.myfile.UserBean;

public interface UserDAO {
	public UserBean getInfo(int userid);

	public UserBean getInfo(String string);

}
