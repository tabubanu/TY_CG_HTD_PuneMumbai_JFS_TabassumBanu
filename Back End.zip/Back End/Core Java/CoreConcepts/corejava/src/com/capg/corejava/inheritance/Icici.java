package com.capg.corejava.inheritance;

public class Icici implements Atm1{

	@Override
	public void validatecard() {
		System.out.println("....connecting to ICICI DB");
		System.out.println("Validating the ICICI card");
		
	}

	@Override
	public void getinfo() {
		System.out.println("....connecting to ICICI DB");
		System.out.println("Getting info of the ICICI card");
	}
	

}
