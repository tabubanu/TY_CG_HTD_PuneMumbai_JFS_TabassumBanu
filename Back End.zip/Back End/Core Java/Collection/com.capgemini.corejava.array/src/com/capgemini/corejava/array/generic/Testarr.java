package com.capgemini.corejava.array.generic;

public class Testarr {

	public static void main(String[] args) {
		char ch []= {'A','P','P','L','E'};
		for(char a : ch)
		{ // using for each loop
			System.out.println(a);
		}
		

	}

}
