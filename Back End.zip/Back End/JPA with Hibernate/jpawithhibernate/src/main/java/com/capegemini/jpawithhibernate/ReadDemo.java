package com.capegemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class ReadDemo {

	public static void main(String[] args) {

		Movie movie = new Movie();
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Movie data=entityManager.find(Movie.class,1);//find(entityname.class,primary key)
		System.out.println("ID---"+data.getId());
		System.out.println("Name---"+data.getName());
		System.out.println("Rating---"+data.getRatings());	
	}

}
