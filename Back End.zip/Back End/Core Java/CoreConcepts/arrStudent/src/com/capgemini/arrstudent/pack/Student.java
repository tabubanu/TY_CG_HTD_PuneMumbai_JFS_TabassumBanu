package com.capgemini.arrstudent.pack;

public class Student {
	int id;
	String name;
	double percentage;
	char gender;

	public Student(int id, String name, double percentage, char gender) {
		super();
		this.id = id;
		this.name = name;
		this.percentage = percentage;
		this.gender = gender;
	}
	public Student()
	{
		
	}

	
	
}
