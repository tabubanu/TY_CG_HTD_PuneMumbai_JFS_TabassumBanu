package com.capgemini.collectionframework;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestK {

	public static void main(String[] args) {
		ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.4);
		al.add(24.5);
		al.add(5.3);
		al.add(6.8);
		al.add(4.1);
		ListIterator<Double> li = al.listIterator();

		while(li.hasNext())
		{
			Double r = li.next();
			System.out.println(r);
		}
		System.out.println("<--------------BackWard");
		while(li.hasPrevious())
		{
			Double r = li.previous();
			System.out.println(r);
		}
	}

}
