package com.capgemini.seleniumDemo;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.selenium.bean.Calculator;

public class TestCalculator {

	Calculator cal = new Calculator();
	@Test
	public void addTest() {
		
		int a =10;
		int b= 20;
		int Expected = 30;
		int actual= cal.add(a,b);
		
		Assert.assertEquals(Expected, actual);
	}
	@Test
	public void subTest() {
	 int a = 30;
	 int b =20;
	 int Expected = 10;
	 int actual = cal.sub(a,b);
	 Assert.assertEquals(Expected, actual);
	}
	
	@Test
	public void mulTest() {
	 int a = 5;
	 int b =20;
	 int Expected = 10;
	 int actual = cal.mul(a,b);
	 Assert.assertEquals(Expected, actual);
	}
	@Test
	public void divTest() {
		int a =10;
		int b =5;
		int Expected = 2;
		int actual = cal.div(a, b);
		Assert.assertEquals(Expected, actual);
		
	}
}
