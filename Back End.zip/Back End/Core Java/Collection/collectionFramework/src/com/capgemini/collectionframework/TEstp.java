package com.capgemini.collectionframework;

import java.util.ArrayList;
import java.util.Iterator;

public class TEstp {
	public static void main(String []args)
	{
		ArrayList <Student> a1= new ArrayList<Student>();
		
		Student s1 =new Student(1," anu" ,13124);
		Student s2 =new Student(2,"tanu" ,325);
		Student s3 =new Student(3,"tabu" ,325);
		Student s4 =new Student(4,"banu" ,325);
		Student s5 =new Student(5,"gersv" ,325);
		 a1.add(s1);
		 a1.add(s2);
		 a1.add(s3);
		 a1.add(s4);
		 a1.add(s5);
		 
		 for(int i=0;i<4;i++) {
			 Student s = a1.get(i);
		
			 System.out.println("Name is:"+s.name);
			 System.out.println("ID is:"+s.id);
			 System.out.println("Percentage is:"+s.percentage);
		 }
		 
		 for(Student m :a1)
		 {
			 System.out.println(m);
		 }
		 
		 Iterator<Student>i =a1.iterator();
		 while(i.hasNext())
		 {
			 Student t = i.next();
			 System.out.println(t);
		 }
			System.out.println("***************listiterator");
			
		
	}

}
