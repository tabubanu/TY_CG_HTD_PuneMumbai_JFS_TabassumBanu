package com.capg.corejava.inheritance;

public class Marker extends Pen {
	double size;
	void color()
	{
		System.out.println("the color is green");
		
	}
	

}
