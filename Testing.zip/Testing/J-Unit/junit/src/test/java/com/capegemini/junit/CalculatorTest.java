package com.capegemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	private Calculator calculator = null;

	@BeforeEach
	public void createobj() {
		calculator = new Calculator();
	}

	@Test
	public void addTest() {
		int e = calculator.add(10, 2);
		assertEquals(12, e);
	}// End of add()

	@Test
	public void divTest() {
		int f = calculator.div(15, 3);
		assertEquals(5, f);
	}// End of div

	@Test
	public void divTestByZero() {
		assertThrows(ArithmeticException.class, () -> calculator.div(10, 0));
	}// End of divTestByZero

	@Test
	public void multest() {
		int g = calculator.mul(5, 3);
		assertEquals(15, g);
	}// End of mul

	@Test
	public void subtest() {
		int h = calculator.sub(15, 3);
		assertEquals(12, h);
	}// End of sub

	@Test
	public void factortest() {
		int h = calculator.factor(5);
		assertEquals(120, h);
	}// End of fact

	@Test
	public void addnegativetest() {
		int e = calculator.add(-10, 5);
		assertEquals(-5, e);
	}// End of add()

}// End of TestCalculator
