package com.capgemini.arrstudent.pack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class Helper1 {

	
		

	void display(ArrayList<Student> m) {

		Iterator<Student> it = m.iterator();
		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is:" + s.name);
			System.out.println("ID is:" + s.id);
			System.out.println("Percentage is:" + s.percentage);
			System.out.println("Gender is:" + s.gender);
			System.out.println("------------------------------------");

		}
	}

	void displayFailedBygen(ArrayList<Student> m) {
		List<Student> li = m.stream().filter(i -> i.percentage < 35 && i.gender=='M').collect(Collectors.toList());
		Iterator<Student> it = li.iterator();
		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is:" + s.name);
			System.out.println("ID is:" + s.id);
			System.out.println("Percentage is:" + s.percentage);
			System.out.println("Gender is:" + s.gender);
			System.out.println("------------------------------------");
		}
	}

	void displayPassed(ArrayList<Student> m) {
		List<Student> li = m.stream().filter(i -> i.percentage >35).collect(Collectors.toList());
		Iterator<Student> it = li.iterator();
		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is:" + s.name);
			System.out.println("ID is:" + s.id);
			System.out.println("Percentage is:" + s.percentage);
			System.out.println("Gender is:" + s.gender);
			System.out.println("------------------------------------");
		}

	}

	void displayPassedBygen(ArrayList<Student> m) {
		List<Student> li = m.stream().filter(i -> i.percentage > 35 && i.gender == 'F').collect(Collectors.toList());
		Iterator<Student> it = li.iterator();
		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is:" + s.name);
			System.out.println("ID is:" + s.id);
			System.out.println("Percentage is:" + s.percentage);
			System.out.println("Gender is:" + s.gender);
			System.out.println("------------------------------------");

		}

	}

	void displayFailed(ArrayList<Student> m)
	{
	List <Student> li = m.stream().filter(i->i.percentage<35).collect(Collectors.toList());
			Iterator<Student> it = li.iterator();
			while(it.hasNext())
			{
				Student s = it.next();
				System.out.println("Name is:"+s.name);
				System.out.println("ID is:"+s.id);
				System.out.println("Percentage is:"+s.percentage);
				System.out.println("Gender is:"+s.gender);
				System.out.println("------------------------------------");
				
			}
	}
	void displayTopper(ArrayList<Student>st)
	{
	
	Comparator<Student> comp = (s1,s2)->
	{
	if(s1.percentage>s2.percentage)
	{
		return 1;
	}
	else if (s1.percentage<s2.percentage)
	{
		return -1;
	}
	else
	{
		return 0;
	}
	};
	  Student displayTopper= st.stream().max(comp).get();
	System.out.println("topper is :"+displayTopper.percentage);
	System.out.println("name is:"+displayTopper.name);
	System.out.println("Id is:"+displayTopper.id);
	System.out.println("Gender is:"+displayTopper.gender);
	
	
	
	}

}
