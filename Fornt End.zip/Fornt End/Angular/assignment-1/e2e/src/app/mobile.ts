export class Mobile{
    constructor(
        public brand,
        public imgURL,
        public price,
        public specs
    ){}
}