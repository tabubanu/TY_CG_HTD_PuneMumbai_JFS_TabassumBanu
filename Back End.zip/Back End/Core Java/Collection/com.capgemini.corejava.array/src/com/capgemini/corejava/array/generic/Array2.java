package com.capgemini.corejava.array.generic;

public class Array2 {
	 public static void main(String[] args) {
		int [] j = new int[4];
		j[0]=9;
		j[1]=6;
				j[2]=5;
		j[3]=0;
		//j[-1]=23;  ArrayoutofBound exception
		for(int i=0;i<j.length;i++)
		{
			System.out.println(j[i]);
		}
		
	}

}
