package com.capgemini.collectionframework;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Vector;

public class TestN {

	public static void main(String[] args) {
	
		Vector li = new Vector();
		li.add(2.4);
		li.add("anu");
		li.add(5.3);
		li.add('k');
		li.add(4);
		System.out.println("**************for loop***************");
		for(int i =0;i<4;i++)
		{
			Object a = li.get(i);
			System.out.println(a);
		}
		
		System.out.println("**************for each loop***************");
		for( Object m  : li)
		{
			System.out.println(m);
		}
		
		
		System.out.println("**************Iterator***************");
		Iterator it = li.iterator();
		while(it.hasNext())
		{
			Object o = it.next();
			System.out.println(o);
			
		}
		System.out.println("----------->forWard");
		ListIterator lit = li.listIterator();
		
		while(lit.hasNext())
		{
			Object k = lit.next();
			System.out.println(k);
			
		}
		System.out.println("<----------BackWard");
		while(lit.hasPrevious())
		{
			Object k = lit.previous();
			System.out.println(k);
			
		}
		
	}

}
