package com.capgemini.Sorting;

import java.util.Iterator;
import java.util.TreeSet;

public class TestTree {

	public static void main(String[] args) {
		TreeSet <EmployeeTree> ts = new TreeSet<EmployeeTree>();
		EmployeeTree e1 = new EmployeeTree(1,"Deepa",1200.56);
		EmployeeTree e2 = new EmployeeTree(2,"mahi",1500.70);
		EmployeeTree e3 = new EmployeeTree(3,"sana",1800.89);
		
		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		
		Iterator <EmployeeTree> ite = ts.iterator();
		while(ite.hasNext())
		{
			EmployeeTree e = ite.next();
			System.out.println("Name is:"+e.name);
			System.out.println("Id is:"+e.id);
			System.out.println("Salary is:"+e.salary);
			System.out.println("****************");
			
		}
		

}
}
