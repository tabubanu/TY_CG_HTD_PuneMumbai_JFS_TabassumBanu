package com.capgemini.jdbc;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;



public class newfile {

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		FileReader reader=null;
		Properties prop=null;
		Scanner sc =new Scanner(System.in);
		ResultSet rs = null;
		try {
			java.sql.Driver driver= new com.mysql.jdbc.Driver();
			DriverManager.registerDriver(driver);
			System.out.println("Driver Loaded..... ");
			System.out.println("***********");
			
			//
			reader = new FileReader("C:\\Users\\my\\Desktop\\db.properties");
			 prop = new Properties();
			prop.load(reader);
			String dbUrl=prop.getProperty("dbUrl");
			conn = DriverManager.getConnection(dbUrl, prop.getProperty("user"),prop.getProperty("password"));
			System.out.println("Connection Established...........");
			System.out.println("-------------------------------------");
			
			
			//Issue SQL Query via Connection
			String query = "SELECT * FROM users_info";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			
			//Process the results returned by SQL query
			while(rs.next())
			{
				System.out.println("User Id: "+rs.getInt(1));
				System.out.println("User Name: "+rs.getString(2));
				System.out.println("Email: "+rs.getString(3));
				System.out.println("Password: "+rs.getString(4));
				System.out.println("****************");
			}
			} 
		catch (Exception e) {
		
			
			e.printStackTrace();
			
		} 

		finally {
			if(conn != null)
			{
				try {
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			if(stmt!=null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
			sc.close();
		
		}
		
		

	


	}

}
