package com.capgemini.encapsulation;

public class DataBase {
	void receive(Student t)
	{
		System.out.println("*********DATABASE***********");
		System.out.println("Id is:"+t.getId());
		System.out.println("Name is:"+t.getName());
		System.out.println("Height is:"+t.getheight());
	}
	void receive(Employee e)
	{
		System.out.println("*********DATABASE OF EMP***********");
		System.out.println("Id is:"+e.getId());
		System.out.println("Name is:"+e.getName());
		System.out.println("Salary is:"+e.getSalary());
		System.out.println("Role is:"+e.getRole());
		System.out.println("Department is"+e.getDepartment());
	}

}
