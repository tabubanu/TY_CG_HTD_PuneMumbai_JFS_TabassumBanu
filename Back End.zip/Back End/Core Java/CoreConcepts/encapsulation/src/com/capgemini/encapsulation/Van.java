package com.capgemini.encapsulation;
//Singleton class
public class Van {
	private static final Van ref = new Van();//static final variable which storers the current object
	private Van()//should have a private constructor
	{
		
	}
	public static Van getVan()//public static ehich returns the stored object
	{
		return ref;
	}

}
