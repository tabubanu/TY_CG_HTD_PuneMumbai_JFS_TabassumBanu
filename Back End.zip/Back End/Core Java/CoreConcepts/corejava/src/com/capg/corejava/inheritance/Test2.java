package com.capg.corejava.inheritance;

public class Test2 {

	public static void main(String[] args) {
		SBI s = new SBI();
		Icici b = new Icici();
		
		Machine m = new Machine();
		m.slot(b);
		m.slot(s);

	}

}
