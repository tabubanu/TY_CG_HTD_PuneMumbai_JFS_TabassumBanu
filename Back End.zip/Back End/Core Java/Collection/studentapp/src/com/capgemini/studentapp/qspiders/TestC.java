package com.capgemini.studentapp.qspiders;

//import static com.capgemini.studentapp.jspiders.Remote.*;
import  com.capgemini.studentapp.jspiders.Remote;
public class TestC {

	public static void main(String[] args) {
		Remote r = new Remote();
		r.off();
		System.out.println(r.count);
		Remote.on();
		System.out.println(Remote.sum);
		
	}

}
