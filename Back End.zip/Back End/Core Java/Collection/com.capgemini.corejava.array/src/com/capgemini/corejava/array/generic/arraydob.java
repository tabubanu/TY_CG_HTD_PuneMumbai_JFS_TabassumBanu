package com.capgemini.corejava.array.generic;

public class arraydob {

	public static void main(String[] args) {
		double d []= {23.8,7.9,8.9,6.89};
		for(double a:d) // for each loop
		{
			System.out.println(a);
		}
	}

}
