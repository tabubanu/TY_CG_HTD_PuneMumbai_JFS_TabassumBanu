package com.capegemini.junit;

import java.util.HashSet;
import java.util.Set;

public class TestM {
public static void main(String[] args) {
	

	Set numsvar = new HashSet<String>();
	
	numsvar.add("5");
	numsvar.add(5);
	System.out.println(numsvar);
}
}
