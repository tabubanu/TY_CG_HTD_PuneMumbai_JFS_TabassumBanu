package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.ListIterator;

public class Testd {

	public static void main(String[] args) {
		LinkedHashSet hs =new LinkedHashSet();
		hs.add("Deepa");
		hs.add(15);

		hs.add(1.5);

		hs.add('A');

		System.out.println("****FOR EACH LOOP******");
		for(Object r :hs)
		{
			System.out.println(r);
			
		}
		System.out.println("******ITERATOR********");
		Iterator it = hs.iterator();
		while(it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
		

	}

}
