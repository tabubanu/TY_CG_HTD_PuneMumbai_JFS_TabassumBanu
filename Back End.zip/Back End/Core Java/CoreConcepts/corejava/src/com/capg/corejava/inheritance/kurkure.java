package com.capg.corejava.inheritance;

public class kurkure implements Chips {

	@Override
	public void open() {
	System.out.println("open kurkure");	

	}

	@Override
	public void eat() {
		System.out.println("eat kurkure");
		

	}

}
