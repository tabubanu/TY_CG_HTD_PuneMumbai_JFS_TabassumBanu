package com.capegemini.junit;

public class Test {

	public static void main(String[] args) {
		 
		Student s = new Student("Tabu", 67.9,'F');
		
		Student s2 = new Student("Simran", 37.2, 'F');
		
		School sc = new School();
		
		sc.studentRegister(null);
		Student regStu = sc.studentRegister(s);
		Student regStu2 = sc.studentRegister(s2);
		
		System.out.println("ID is " +regStu.getId());
		System.out.println("Name is " +regStu.getName());
		
		System.out.println("---------------------------------------");
		
		System.out.println("ID is " +regStu2.getId());
		System.out.println("Name is " +regStu2.getName());
		
		
	}
}
