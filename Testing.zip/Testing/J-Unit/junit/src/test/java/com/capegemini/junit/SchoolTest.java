package com.capegemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SchoolTest {

	private School school;
	
	@BeforeEach
	public void createObject() {
		school = new School();
	}
	
	@Test
	public void testRegisterStudent() {
		Student student = new Student("Dimple", 78.8, 'F');
		Student stu = school.studentRegister(student);
		assertEquals(1, stu.getId());
	}// testRegisterStudent()
	
	@Test
	public void testRegisterStudentForNull() {
		assertThrows(NullPointerException.class, ()->school.studentRegister(null));
	}
}// End of schoolTest



