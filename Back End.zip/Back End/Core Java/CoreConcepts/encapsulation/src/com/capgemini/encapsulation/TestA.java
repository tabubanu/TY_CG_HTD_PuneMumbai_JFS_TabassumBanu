package com.capgemini.encapsulation;

public class TestA {

	public static void main(String[] args) {
	Student s =new Student();
	s.setId(70);
	s.setName("tabu");
	s.setHeight(5.7);
	
	DataBase db=new DataBase();
	db.receive(s);

	
	Employee emp = new Employee();
	emp.setId(23);
	emp.setName("Banu");
	emp.setSalary(30000);
	emp.setRole("Full Stack Developer");
	emp.setDepartment("cs");
	db.receive(emp);

	}

}
