package com.capgemini.collectionframework;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestD {
public static void main(String[] args) {
		
		ArrayList al= new ArrayList();
		al.add(23);
		al.add("Tabassum");
		al.add(29.0);
		al.add('t');
		System.out.println("----------------> Forward");
		
		ListIterator m = al.listIterator();
		while(m.hasNext())
		{
		Object r = m.next();
		System.out.println(r);
		}
		System.out.println("<---------------- Backward");
		while(m.hasPrevious())
		{
		Object r = m.previous();
		System.out.println(r);
		}
	}
}

