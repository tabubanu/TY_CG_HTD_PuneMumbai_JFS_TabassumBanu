package com.capgemini.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts1 {

	public static void main(String[] args) {

		Pattern pat = Pattern.compile("\\d{10}");
		Matcher mat = pat.matcher("1234567890");
		System.out.println("For pattern \\d+:"+mat.matches());
		
		Pattern pat1 = Pattern.compile("\\d");
		Matcher mat1 = pat1.matcher("1");
		System.out.println("For pattern \\d:"+mat1.matches());
		
		Pattern pat2 = Pattern.compile("\\d+");
		Matcher mat2 = pat2.matcher("123456789012345677888");
		System.out.println("For pattern \\d+:"+mat2.matches());
		
		Pattern pat3 = Pattern.compile("\\d{0}");
		Matcher mat3 = pat3.matcher("");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{0}:"+mat3.matches());
		
		Pattern pat4 = Pattern.compile("\\d{0}");
		Matcher mat4 = pat4.matcher("1");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{0}:"+mat4.matches());
	
		Pattern pat5 = Pattern.compile("\\d{1,9}");
		Matcher mat5 = pat5.matcher("123456789");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{0}:"+mat5.matches());
		
		Pattern pat6 = Pattern.compile("\\d{1,9}");
		Matcher mat6 = pat6.matcher("");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{1,9}:"+mat6.matches());
		
		Pattern pat7 = Pattern.compile("\\d{1,9}");
		Matcher mat7 = pat7.matcher("1234567890");
		//it takes values upto 10 but if we give only single digit it will return false
		System.out.println("For pattern \\d{1,9}:"+mat7.matches());
		
		Pattern pat8 = Pattern.compile("\\D");
		Matcher mat8 = pat8.matcher(" ");
		//it makes sure that whatever the data given can be anything but not a digit
		System.out.println("For pattern \\D{1,9}:"+mat8.matches());
		
		 pat8 = Pattern.compile("\\D");
	     mat8 = pat8.matcher(" ");
		//it makes sure that whatever the data given can be anything but not a digit
		System.out.println("For pattern \\D:"+mat8.matches());
		
		pat8 = Pattern.compile("\\D");
	     mat8 = pat8.matcher("a");
		//it makes sure that whatever the data given can be anything but not a digit
		System.out.println("For pattern \\D:"+mat8.matches());
		
		pat8 = Pattern.compile("\\D+");
	     mat8 = pat8.matcher("AaBbCc ");
		//it makes sure that whatever the data given can be anything but not a digit
		System.out.println("For pattern \\D+:"+mat8.matches());
		
		//single s for  one space,s+ for more than one space
		
		pat8 = Pattern.compile("\\s");
	     mat8 = pat8.matcher(" ");
		//it makes sure that whatever the data given can be anything but not a digit
		System.out.println("For pattern \\s:"+mat8.matches());
		
		pat8 = Pattern.compile("\\s+");
	     mat8 = pat8.matcher("      ");
		//it makes sure that whatever the data given can be anything but not a digit
		System.out.println("For pattern \\s+:"+mat8.matches());
		
		//if we don't want take space we can use S.
		pat8 = Pattern.compile("\\S");
	     mat8 = pat8.matcher("a");
		//it makes sure that whatever the data given can be anything but not a digit
		System.out.println("For pattern \\S:"+mat8.matches());
	
	
	}
	

}
