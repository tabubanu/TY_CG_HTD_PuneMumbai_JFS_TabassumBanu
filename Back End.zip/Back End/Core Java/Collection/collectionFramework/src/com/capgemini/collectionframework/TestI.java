package com.capgemini.collectionframework;

import java.util.ArrayList;

public class TestI {

	public static void main(String[] args) {
		ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.4);
		al.add(24.5);
		al.add(5.3);
		al.add(6.8);
		al.add(4.1);
		
		for(double d : al)
		{
			System.out.println(d);
		}

	}

}
