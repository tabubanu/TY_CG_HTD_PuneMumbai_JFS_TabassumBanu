package com.capgemini.collectionframework;

import java.util.ArrayList;
import java.util.Iterator;

public class TestF {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add("priya");
		al.add(2);
		al.add('F');
		al.add(5.6);
		
		Iterator l = al.iterator();
		
		while(l.hasNext())
		{
			Object i = l.next();
			System.out.println(i);
		}
	}

}
