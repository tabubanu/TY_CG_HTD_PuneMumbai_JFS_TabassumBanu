package com.capegemini.jpawithhibernetpractice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernatepractice.dto.Channel;



public class Referch {

	public static void main(String[] args) {
		 Channel channel = new Channel();
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Channel ch=entityManager.getReference(Channel.class,1002);//getReference(entityname.class,primary key)
		
		System.out.println(ch.getChname());

	}

}
