package com.capgemini.Sorting;

import java.util.Comparator;

public class ByMicr implements Comparator <Bank> {

	public static void main(String[] args) {
		

	}

	@Override
	public int compare(Bank o1, Bank o2) {
		Long i = o1.micr;
		Long k = o2.micr;
		return k.compareTo(k);
	}

}
