package com.capgemini.stringexp.one;

public class Testb {

	public static void main(String[] args) {
		
		String k = "90";
		String t = "50";
		System.out.println(k+t);
		int i = Integer.parseInt(k);
		int p = Integer.parseInt(t);
		System.out.println(i+p);
		String q = "65.23";
		double r = Double.parseDouble(q);
		System.out.println(r);
		
		

	}

}
