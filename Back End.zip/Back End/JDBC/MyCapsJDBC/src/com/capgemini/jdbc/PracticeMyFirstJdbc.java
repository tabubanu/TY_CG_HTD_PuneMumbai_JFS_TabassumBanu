package com.capgemini.jdbc;

import java.io.ObjectInputStream.GetField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class PracticeMyFirstJdbc {

	public static void main(String[] args) {

		//Load the Driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded");
			System.out.println("------------------------");
			
			//Establish connection
			String dbUrl="jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			Connection conn = DriverManager.getConnection(dbUrl);
			System.out.println("Connection established");
			System.out.println("--------------------------------------");
			
			//Issue sql query
			String query ="Select * from users_info";
			Statement stmt =conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next())
			{
				System.out.println("name is:"+rs.getInt(1));
				System.out.println("Mail is"+rs.getString(2));
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
