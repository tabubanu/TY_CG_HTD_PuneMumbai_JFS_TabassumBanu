export class Laptop{
    constructor(
        public brand:string,
        public imgURL:string,
        public price:number,
        public specs: string
    ){}
}