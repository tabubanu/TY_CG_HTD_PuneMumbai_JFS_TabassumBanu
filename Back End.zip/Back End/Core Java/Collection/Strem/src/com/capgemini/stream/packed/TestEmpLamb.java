package com.capgemini.stream.packed;

import java.util.Comparator;
import java.util.TreeSet;

public class TestEmpLamb {

	public static void main(String[] args) {
		Comparator<Employee> comp= (e1,e2)->
		{
			if(e1.height>e2.height)
			{
				return 1;
			}
			else if(e1.height<e2.height)
			{
				return -1;	
			}
				
			else
		
		{
			return 0;
		}

		
	};
	TreeSet<Employee>ts = new TreeSet<Employee>(comp);
	Employee e1 = new Employee(1,"neha",4.6);
	Employee e2 = new Employee(2,"anu",5.6);
	Employee e3 = new Employee(3,"reema",3.6);
	Employee e4 = new Employee(4,"nani",6.6);
	
	ts.add(e1);
	ts.add(e2);
	ts.add(e3);
	ts.add(e4);
	for (Employee e :ts) {
		System.out.println("Id is: "+e.id);
		System.out.println("Name is: "+e.name);
		System.out.println("Height is: "+e.height);
	}
	

			
		
			}
}





