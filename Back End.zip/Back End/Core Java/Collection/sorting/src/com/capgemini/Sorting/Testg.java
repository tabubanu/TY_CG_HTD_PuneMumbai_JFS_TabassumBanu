package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;

public class Testg {

	public static void main(String[] args) {
		HashSet<Employee> hs =new HashSet<Employee>();
		Employee e1 = new Employee(1,"Tabu",1200.69);
		Employee e2 = new Employee(2,"Sne",1430.69);
		Employee e3 = new Employee(3,"edw",15009.69);
		Employee e4 = new Employee(4,"rock",1400.90);
		Employee e5 = new Employee(5,"popper",1500.69);
		Employee e6 = new Employee(3,"edw",15009.69);
		hs.add(e1);
		hs.add(e2);
		hs.add(e3);
		hs.add(e4);
		hs.add(e5);
		hs.add(e6);
		/*
		 * System.out.println("********Using For Each loop*******");
		 * 
		 * for(Employee r :hs) { System.out.println("Name of Employee:"+r.name);
		 * System.out.println("Name of ID:"+r.id);
		 * System.out.println("Name of Salary:"+r.salary);
		 * System.out.println("*********************");
		 * 
		 * }
		 */
		System.out.println("********Using Iterator*******");
		Iterator<Employee> it = hs.iterator();
		while(it.hasNext())
		{
			Employee r = it.next();
			System.out.println("Name of Employee:"+r.name);
			System.out.println("Name of ID:"+r.id);
			System.out.println("Name of Salary:"+r.salary);
			System.out.println("*********************");
			
		}

		
		

	}

}
