package com.capgemini.collectionframework;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class TestL {

	public static void main(String[] args) {
		
		LinkedList<Double> li = new LinkedList<Double>();
		li.add(2.4);
		li.add(24.5);
		li.add(5.3);
		li.add(6.8);
		li.add(4.1);
		
		System.out.println("********for loop");
		for (int i = 0;i<5;i++)
		{
			
			Object r = li.get(i);
			System.out.println(r);
		}
		System.out.println("*********for each");
		for(Object i : li)
		{
			System.out.println(i);
		}
		
		
		System.out.println("*********Iterator");
		
		Iterator it = li.iterator();
		
		while(it.hasNext())
		{
			Object k = it.next();
			System.out.println(k);
			
		}
		System.out.println("***************listiterator");
		ListIterator m = li.listIterator();
		while(m.hasNext())
		{
		Object r = m.next();
		System.out.println(r);
		}
		System.out.println("<---------------- Backward");
		while(m.hasPrevious())
		{
		Object r = m.previous();
		System.out.println(r);
		}
		
		
	}

}
