package com.capgemini.collectionframework;

import java.util.ArrayList;

public class TestH {

	public static void main(String[] args) {
		
		ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.4);
		al.add(24.5);
		al.add(5.3);
		al.add(6.8);
		al.add(4.1);
		
		for(int i=0;i<5;i++)
		{
			Double d = al.get(i);
			System.out.println(d);
		}
		

	}

}
