package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Project {

	public static void main(String[] args) throws Exception {

		int choice = 1;
		Statement st=null;
		//Load Driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded");
			System.out.println("----------------------");
			
			//Establish Connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			Connection conn = DriverManager.getConnection(dbUrl);
			System.out.println("connection Established");
			System.out.println("---------------------------------");
		}
			catch (Exception e) {
				
				e.printStackTrace();
			}
			 
			
			//Issue Query
			do {
				System.out.println("1.Menu card");
				System.out.println("2.Insert item");
				System.out.println("3.Update item");
				System.out.println("4.Remove item");
				System.out.println("5.Total bill");
				switch(choice)
				{
				case 1:
					System.out.println("hello");
					//st.executeUpdate("Select * from users_info");
					
					
				case 2:
					st.executeUpdate("Insert into users_info" +"values(1002,'biryani',200)");
					
				case 3:
					ResultSet rs = st.executeQuery("delete from users_info");
			
				}
			}
				while(choice!=6);
	
			
				
			
			
	}
	
			}
		
			
		
		
		
	


