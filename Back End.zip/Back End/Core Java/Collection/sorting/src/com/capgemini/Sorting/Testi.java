package com.capgemini.Sorting;

import java.util.HashSet;


public class Testi {

	public static void main(String[] args) {
		HashSet hs =new HashSet();
		hs.add(15);
		hs.add('A');//HashSet doesn't not duplicates values.even if theerre are duplicates it dicsards one.
		hs.add(2.4);
		hs.add("Deepa");
		hs.add(15);
		hs.add('A');
		hs.add(null);
		hs.add(null);
		
		System.out.println("****FOR EACH LOOP******");
		for(Object r :hs)
		{
			System.out.println(r);
			
		}

	}

}
