package com.capg.corejava.cfs;

public class MethodExample {

	public static void main(String[] args) {
		

	}

}
