package com.capegemini.jpawithhibernetpractice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernatepractice.dto.Channel;



public class Updatehi {

	public static void main(String[] args) {
		
			EntityManager entityManager = null;
			EntityTransaction transaction = null;
			Channel channel = new Channel();
			
			try {
				EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("test");
				entityManager = entityManagerFactory.createEntityManager();
				transaction = entityManager.getTransaction();
				transaction.begin();
				 Channel ch=entityManager.find(Channel.class,1003);
				ch.setChno(178);
				System.out.println("Record saved");
				transaction.commit();
			} catch (Exception e) {
				transaction.rollback();
				e.printStackTrace();

			}
			entityManager.close();
	}

}
