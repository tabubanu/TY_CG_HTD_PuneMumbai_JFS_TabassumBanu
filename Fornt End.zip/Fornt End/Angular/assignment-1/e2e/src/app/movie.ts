export class Movie{
    constructor(
        public name:string,
        public imgURL:string,
        public rating: number,
        public spec:string
        
    ){}
}