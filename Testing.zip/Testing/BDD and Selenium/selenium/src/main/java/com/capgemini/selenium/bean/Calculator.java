package com.capgemini.selenium.bean;

public class Calculator {

	public int add(int x, int y) {
		return x+y;
	}
	public int sub(int a, int b) {
		return a-b;
	}
	public int mul(int a , int b) {
		return a*b;
	}
	public int div(int x, int y) {
		return x/y;
	}
}
