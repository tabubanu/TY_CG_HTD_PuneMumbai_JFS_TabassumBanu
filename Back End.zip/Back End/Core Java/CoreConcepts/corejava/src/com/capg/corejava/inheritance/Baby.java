package com.capg.corejava.inheritance;

public class Baby {
	void receive(Chips c)
	{
		
	}
	void open()
	{
		
		
	}
	void eat()
	{
		
	}

}
