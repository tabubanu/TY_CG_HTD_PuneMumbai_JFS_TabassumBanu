package com.capg.corejava.inheritance;

public class Car extends Driver {
	
	{
		
	}

}
