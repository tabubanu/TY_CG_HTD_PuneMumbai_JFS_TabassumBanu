package com.capgemini.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springboot.beans.EmployeeInfoBean;
import com.capgemini.springboot.beans.EmployeeResponse;
import com.capgemini.springboot.service.EmployeeService;

 //@Controller


@RestController // to show that all methods are not views and are actual objects
@CrossOrigin(origins = "*", allowedHeaders="*")
public class EmployeeRestController {

	@Autowired
	private EmployeeService service;
	
	@GetMapping(path = "/getEmployee", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ResponseBody  // to know it is actual response
	public EmployeeResponse getEmployees(int empId) {
		EmployeeInfoBean employeeInfoBean = service.getEmployee(empId);
		EmployeeResponse response = new EmployeeResponse();
		if(employeeInfoBean != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee Record Found!!!");
			response.setEmployeeInfoBean(employeeInfoBean);
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Employee ID" +empId + " not found !!!!!!");
			
		}
		return response;
		
	}// End of getEmployees()
	@PutMapping(path = "/addEmployee", consumes = {  MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public EmployeeResponse addEmployee(@RequestBody EmployeeInfoBean employeeInfoBean) {
		boolean isAdded = service.addEmployee(employeeInfoBean);
		
		EmployeeResponse response = new EmployeeResponse();
		if(isAdded) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee Added Successfully..........");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to add Employee!!!");
		}
		return response;
	}// End of addEmployee()
	
	@DeleteMapping(path = "/deleteEmployee/{employeeId}",
			produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public EmployeeResponse deleteEmployee(@PathVariable("employeeId")int empId) {
		boolean isDelete = service.deleteEmployee(empId);
		EmployeeResponse response = new EmployeeResponse();
		
		if(isDelete) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee Deleted Successfully..........");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to delete Employee!!!");
		}
		return response;
	}// End of deleteEmployee()
	
	@PostMapping(path = "/updateEmployee", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE },
			consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public EmployeeResponse updateEmployee(@RequestBody EmployeeInfoBean employeeInfoBean) {
		boolean isUpdate = service.updateEmployee(employeeInfoBean);
		
		EmployeeResponse response = new EmployeeResponse();
		
		if(isUpdate) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee Update Successfully..........");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to Update Employee!!!");
		}
		return response;
		
	}
	
	@GetMapping(path = "/getAll",
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }
			)
	public EmployeeResponse getAllEmployees() {
		List<EmployeeInfoBean> employeeList = service.getAllEmployees();
		EmployeeResponse response = new EmployeeResponse();
		
		if(employeeList!= null && !employeeList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee Record Found!!!");
			response.setEmployeeList(employeeList);
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to fetch rcord");
			
		}
		return response;
	}
}// End of Controller
