package com.capg.corejava.inheritance;

public class TestB {

	public static void main(String[] args) {
	Lays r = new Lays();
	
		Baby b = new Baby();
		b.receive(r);

	}

}
