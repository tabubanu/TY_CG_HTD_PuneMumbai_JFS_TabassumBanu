package com.capg.corejava.interfaces;

public interface InterfaceExample {
	public void display();
	public void show();
}
