package com.capgemini.springcore.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class MessageBean2 {
	private String message;

	public MessageBean2() {
		System.out.println(" Inside Constructor");
		
	}
	//Getter Setter methods
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public void init() {
		System.out.println("its Init Phase...");
	}
	
	public void destroy() {
		System.out.println("Its destroy Phase!");
	}

}//End of class
