package com.capg.corejava.cfs;

public class Car {
	String name;
	String color;
	double price;

	public Car(String name, String color, double price) {
		super();
		this.name = name;
		this.color = color;
		this.price = price;
	}

}
