package com.capegemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.hibernate.onetoone.Person;
import com.capgemini.hibernate.onetoone.VoterCard;
import com.capgemini.jpawithhibernate.dto.Movie;

public class TestOnetoOne {

	public static void main(String[] args) {

		EntityManager entityManager = null;
		EntityTransaction transaction = null;
		Person person = new Person();
		person.setPid(2);
		person.setName("banu");
		person.setPid(3);
		person.setName("anu");
		VoterCard vc = new VoterCard();
		vc.setAddress("Banashankari stage 2");
		vc.setVoter_id(7866);
		person.setVoterCard(vc);

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("test");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();
			//entityManager.persist(person);
			VoterCard carddetails=entityManager.find(VoterCard.class,346);
			carddetails.getVoter_id();
			carddetails.getAddress();
			carddetails.getPerson().getPid();
			System.out.println(person.getName());
			System.out.println(person.getPid());
			System.out.println(person.getName());
			System.out.println(carddetails.getPerson().getName());
			System.out.println("Record saved");
			
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			//e.printStackTrace();
			System.out.println("Don't enter Duplicate values");

		}entityManager.close();
		
	}

}
