package com.capgemini.arrstudent.pack;

import java.util.function.Predicate;

public class TestPre {

	public static void main(String[] args) {
		Predicate<Student> p = i->
		{
			if(i.percentage>=35)
			{
				return true;
			}
			else  {
				return false;
			}
		
		};
//		boolean res = p.;
//		boolean res1 = p.test(10);
		Student s = new Student(1,"Sana",45.3,'F');

		boolean res1 = p.test(s);
		System.out.println("Result is: "+s.percentage);
		System.out.println("Result is: "+res1);

	}

}
