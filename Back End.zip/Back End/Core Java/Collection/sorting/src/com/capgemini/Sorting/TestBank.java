package com.capgemini.Sorting;

import java.util.Iterator;
import java.util.TreeSet;

public class TestBank {

	public static void main(String[] args) {
		
		ById comp = new ById();
		ByName comp1 = new ByName();
	TreeSet <Bank> ts = new TreeSet<Bank>(comp1);
	Bank b1 = new Bank(78960,"hina",278745845);
	Bank b2 = new Bank(67590,"innu",85937694);
	Bank b3 = new Bank(739305,"anu",8945865);
	Bank b4 = new Bank(93045,"mani",12888696);
	
	ts.add(b1);
	ts.add(b2);
	ts.add(b3);
	ts.add(b4);
	Iterator <Bank> itb = ts.iterator();
	while(itb.hasNext())
	{
		Bank b=itb.next();
		System.out.println("Pin:"+b.Pin);
		System.out.println("Name:"+b.name);
		System.out.println("micr "+b.micr);
		System.out.println("--------------------------");
	}
	

	}

}
