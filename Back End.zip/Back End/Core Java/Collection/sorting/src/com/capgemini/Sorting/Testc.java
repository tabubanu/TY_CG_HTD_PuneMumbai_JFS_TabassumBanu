package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;

public class Testc {

	public static void main(String[] args) {
		HashSet<String> hs =new HashSet<String>();
		hs.add("Deepa");
		System.out.println("****FOR EACH LOOP******");
		for(String r :hs)
		{
			System.out.println(r);
			
		}
		Iterator<String> it = hs.iterator();
		while(it.hasNext())
		{
			String r = it.next();
			System.out.println(r);
		}
	}

}
