package com.capg.corejava.inheritance;

public class SBI implements Atm1{

	@Override
	public void validatecard() {
		System.out.println("....connecting to SBI DB");
		System.out.println("Validating the SBI card");
		
	}

	@Override
	public void getinfo() {
		System.out.println("....connecting to SBI DB");
		System.out.println("Getting Info of SBI card");
		
	}

}
